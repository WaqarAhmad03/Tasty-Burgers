import React from 'react'
import Layout from '../../Components/Layouts/Layout'

const index = () => {
  return (
    <Layout>
        
    </Layout>
  )
}

export default index
